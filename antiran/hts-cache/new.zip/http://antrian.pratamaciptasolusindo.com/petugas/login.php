<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Login : msAntrian v.1.0.0</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../public/4/united/bootstrap.css">
    <link rel="stylesheet" href="../public/4/vendor/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="../public/4/assets/css/custom.min.css">
  </head>
  
  <body style="background-color:#FFF; background-image:url(../public/images/background.png);">

	<div class="container">
		<div class="row">
			<div class="col-md-4 offset-md-4" align="center">
				<img src="../public/images/logo.png" height="60"><br><br>
			</div>
		</div>
		<div class="row">
			<div class="col-md-4 offset-md-4">
				<div class="card card-default">
					<div class="card-header"><strong>Login Petugas</strong></div>
					<div class="card-body">
						<form method="post" action="login.php?com=validate" enctype="multipart/form-data">
														<div class="form-group row">
								<label class="col-md-4 col-form-label" for="username">Username</label>
								<div class="col-md-8">
									<input type="text" name="username" class="form-control" id="username" placeholder="Username" required="required">
								</div>
							</div>
							<div class="form-group row">
								<label class="col-md-4 control-label" for="password">Password</label>
								<div class="col-md-8">
									<input type="password" name="password" class="form-control" id="password" placeholder="Password" required="required">
								</div>
							</div>
							<div class="form-group row">
														<label class="col-form-label col-sm-4" for="kode_akses">1 + 7 = </label>
							<div class="col-sm-8">
								<input type="hidden" name="kode" value="8">
								<input type="number" name="kode_akses" class="form-control" id="kode_akses" placeholder="Hasil Penjumlahan" required="required">
							</div>
						  </div>
							<div class="form-group row">
								<div class="col-md-8 offset-md-4">
									<button type="submit" class="btn btn-sm btn-info">Login</button>
									<button type="reset" class="btn btn-sm btn-warning">Reset</button>
								</div>
							</div>
						</form>
					</div>
				</div> 
			</div>
		</div>
	</div>
		
    <script src="../public/4/vendor/jquery/dist/jquery.min.js"></script>
    <script src="../public/4/vendor/popper.js/dist/umd/popper.min.js"></script>
    <script src="../public/4/vendor/bootstrap/dist/js/bootstrap.min.js"></script>	
    <script src="../public/4/assets/js/custom.js"></script>
	
  </body>
</html>
